package com.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.eg.A;

@Configuration
public class Config2{
	
	@Bean 
	@Scope("prototype")
	public A getA(int p1, String str, float f){
		return new A(p1,str, f);
	}
}
