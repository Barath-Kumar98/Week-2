package com.eg;

public class A{
	int p1;
	A(int p1, String str){
		this.p1 = p1;
		System.out.println("A()"+p1+str);
	}
	
	public A(int p1, String str, float f){
		this.p1 = p1;
		System.out.println("A()"+p1+str+ f);
	}
	
	public void initBn(){
		System.out.println("initBn()...");
	}
	
	public void destroyBn(){
		System.out.println("destroyBn()...");
	}
	
	@Override
	public String toString(){
		return "a="+p1;
	}
}