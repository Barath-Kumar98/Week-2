import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.config.Config1;
import com.config.Config2;

import com.eg.Employee;
import com.eg.A;

//class A{
//	int p1;
//	A(int p1, String str){
//		this.p1 = p1;
//		System.out.println("A()"+p1+str);
//	}
//	
//	A(int p1, String str, float f){
//		this.p1 = p1;
//		System.out.println("A()"+p1+str+ f);
//	}
//	
//	public void initBn(){
//		System.out.println("initBn()...");
//	}
//	
//	public void destroyBn(){
//		System.out.println("destroyBn()...");
//	}
//	
//	@Override
//	public String toString(){
//		return "a="+p1;
//	}
//}
//
//class Employee{
//	private String name;
//
//	public String getName() {
//		return name;
//	}
//
//	public void setName(String name) {
//		this.name = name;
//	}
//
//	public Employee() {
//		System.out.println("Employee() ");
//	}
//}
//
//@Configuration
//class MyConfig{
//	@Bean 
//	@Scope("prototype")
//	public Employee getEBean(){
//		System.out.println("public Employee getEBean()");
//		return new Employee();
//	}	
//	
//	@Bean 
//	@Scope("prototype")
//	public A getA(int p1, String str, float f){
//		return new A(p1,str, f);
//	}
//}

public class SpringBeaanAnno {
	public static void main(String[] args) {
		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(Config1.class, Config2.class);

		//ctx.register(MyConfig.class);
		//ctx.refresh();
		
		Employee emp = ctx.getBean(Employee.class);
		emp.setName("fevbrgver");
		
		System.out.println(emp.getName());
		
		A oa = ctx.getBean(A.class, 1001, "str111111111");
		System.out.println(oa);
		
		A oa1 = ctx.getBean(A.class, 1002, "str222222222");
		System.out.println(oa1);
		
		A oa2 = ctx.getBean(A.class, 1002, "str222222222", 2.234f);
		System.out.println(oa2);
		
	}
}
