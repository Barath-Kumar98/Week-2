
public class Salary {
	double salaryPerAnnum;

	public Salary() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("Salary Def contructor");
	}

	public Salary(double salaryPerAnnum) {
		super();
		this.salaryPerAnnum = salaryPerAnnum;
	}

	public double getSalaryPerAnnum() {
		return salaryPerAnnum;
	}

	public void setSalaryPerAnnum(double salaryPerAnnum) {
		this.salaryPerAnnum = salaryPerAnnum;
	}

	@Override
	public String toString() {
		return "Salary [salaryPerAnnum=" + salaryPerAnnum + "]";
	}
	
	
}
