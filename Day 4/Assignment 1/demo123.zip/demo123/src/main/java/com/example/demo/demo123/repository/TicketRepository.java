package com.example.demo.demo123.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.example.demo.demo123.model.Ticket;


// Without using JPA
@Component
public class TicketRepository  {
	private List<Ticket> ticketList;
	
	public TicketRepository() {
		ticketList = new ArrayList<>();
	}
	
	public List<Ticket> listTickets() {
		return ticketList;
	}

	public Ticket bookTicket(Ticket ticket) {
		ticketList.add(ticket);
		return ticket;
	}

	public int cancelTicket(int id) {
		ticketList.remove(id);
		return id;
	}
}
