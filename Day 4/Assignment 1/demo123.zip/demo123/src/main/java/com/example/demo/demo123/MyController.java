//package com.example.demo.demo123;
//
//
//
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RestController;
//
// 
//
//@RestController
//public class MyController {
//    @Autowired
//    Xyz obj;
//    
//    @GetMapping("/abc")
//    String met1(){
//        return obj.met9();
//    }
//    
//    @GetMapping("/gettickets")
//    Ticket getTickets(){
//    	return new Ticket(1, "xyz travels", "Chennai", "Hyderabad");
//    }
//    
//    @PostMapping("/bookticket")
//    Ticket bookTicket(@RequestBody Ticket ticket){
//    	ticket.setId(10);
//    	return ticket;
//    }
//}
//
// 
//
//@Component
//class Xyz{
//    
//    String met9(){
//        return "Hello, can you see thsi message111111111";
//        
//    }
//}
//

