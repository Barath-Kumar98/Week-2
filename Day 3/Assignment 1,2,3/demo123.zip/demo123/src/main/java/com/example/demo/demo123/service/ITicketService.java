package com.example.demo.demo123.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.demo123.model.Ticket;
import com.example.demo.demo123.model.User;

@Service
public interface ITicketService {
	public List<Ticket> listTickets();
	
	public List<Ticket> listTicketsByNativeQuery();
	
	public Ticket bookTicket(Ticket ticket);
	
	public int cancelTicket(int id);
	
	public	List<Ticket> getTicketsBySourceDest(String source, String dest);
	

	public	List<Ticket> getTicketsBySourceDestContains(String sourcePart, String destPart);
	
	public List<User> getUsers();
	
	public User createUser(User user);
}
