package com.example91.demo91;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo91ApplicationTests {

	@Test
	void contextLoads() {
	}

}
