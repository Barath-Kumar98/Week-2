package com.example.demo.demo123.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.demo123.model.SourceDestination;
import com.example.demo.demo123.model.Ticket;

@Repository
public interface ITicketRepository extends JpaRepository<Ticket, Integer> {

//	public List<Ticket> findAll();
	
	public List<Ticket> findBySourceAndDestination(String source, String destination);
	
	public List<Ticket> findBySourceContainsAndDestinationContainsIgnoreCase(String source, String destination);
	
	@Query("Select t from Ticket t")
	public List<Ticket> getTickets();
	
	@Query(value="Select distinct t.travelsName from Ticket t")
	public List<Object[]> getAllTravels();
	
	@Query("Select t from Ticket t where t.destination = :destination")
	public List<Ticket> getTicketsByDestination(@Param("destination") String destination);
	
	@Query("Select new com.example.demo.demo123.model.SourceDestination(t.source,t.destination) from Ticket t")
	public List<SourceDestination> getPlaces();
}
