package com.example.demo.demo123.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.demo123.model.Ticket;
import com.example.demo.demo123.model.User;
import com.example.demo.demo123.service.ITicketService;

@RestController
public class TicketController {
	
	@Autowired
	ITicketService itiketService;

	@GetMapping("/getusers")
	ResponseEntity<List<User>> getUsers(){
    	return new ResponseEntity<>(itiketService.getUsers(), HttpStatus.OK);
    }
	
	@PostMapping("/createuser")
    User createUser(@RequestBody User user){
    	return itiketService.createUser(user);
    }
	
	@GetMapping("/gettickets")
	ResponseEntity<List<Ticket>> getTickets(){
    	return new ResponseEntity<>(itiketService.listTickets(), HttpStatus.OK);
    }
	
	@GetMapping("/getbysourcedestination/")
	ResponseEntity<List<Ticket>> getTicketsbysourceDest(@RequestParam("source") String source, @RequestParam("destination") String destination){
    	return new ResponseEntity<>(itiketService.getTicketsBySourceDest(source, destination), HttpStatus.OK);
    }
	
	@GetMapping("/getbysourcedestinationpart/")
	ResponseEntity<List<Ticket>> getTicketsbysourceDestPart(@RequestParam("source") String source, @RequestParam("destination") String destination){
    	return new ResponseEntity<>(itiketService.getTicketsBySourceDestContains(source, destination), HttpStatus.OK);
    }
    
    @PostMapping("/bookticket")
    Ticket bookTicket(@RequestBody Ticket ticket){
    	return itiketService.bookTicket(ticket);
    }
    
    
    // Week 2 Day 2 Assignment 1
    @DeleteMapping("/cancelTicket/{id}")
    int cancelTicket(@PathVariable int id){
    	return itiketService.cancelTicket(id);
    }
}
